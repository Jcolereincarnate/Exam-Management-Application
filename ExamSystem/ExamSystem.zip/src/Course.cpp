#include "Course.h"

Course::Course() 
    : id(0), timeAllocation(60), questionsPerExam(40), 
      passingMark(40), totalQuestions(0) {}