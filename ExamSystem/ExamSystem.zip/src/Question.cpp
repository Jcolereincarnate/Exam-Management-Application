#include "Question.h"

Question::Question() 
    : id(0), courseId(0), points(1) {}