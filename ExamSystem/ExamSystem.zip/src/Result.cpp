#include "Result.h"

Result::Result() 
    : id(0), userId(0), courseId(0), score(0), totalQuestions(0), 
      totalPoints(0), percentage(0), timeSpent(0), passed(false) {}